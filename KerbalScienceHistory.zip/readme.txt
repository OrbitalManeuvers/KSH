
Kerbal Science History
================================


Change Log
--------------
0.1.1.10 - Initial release



Requirements
---------------
- None as far as I know, other an environment that can run 32-bit Windows
  executables.


Installation
--------------
- The exe can live and be run from anywhere. Literally doesn't matter.


Kerbal Science History:
 - DOES NOT create any files
 - DOES NOT contact/use any resources other than the game save file
   indicated by the user


